package com.epsi.cinedirect.models

data class Customer(val name: String)