package com.epsi.cinedirect.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFFFC107)
val PurpleGrey80 = Color(0xFFFFEB3B)
val Pink80 = Color(0xA300BCD4)

val Purple40 = Color(0xFF009688)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)