package com.epsi.cinedirect.models

data class Reservation(val customerName: String)